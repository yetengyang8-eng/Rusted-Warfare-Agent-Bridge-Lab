# Native methods established from the verified game-lib.jar bytecode and actual two-process execution

- `engine.bX.b(false)`: native multiplayer TCP+UDP listener, host local team allocated by `c(false)`; `engine.bs == engine.bX.z`.
- Static network class `b(connect, false)`: official native socket creation and TCP selection (`engine.bQ.udpInMultiplayer=false`). Instance `a(socket)`: official preregistration/registration client.
- `engine.bX.ae()`: native server info/team flush followed by PACKET_START_GAME 120 and `aW=true`.
- Native `com.corrodinggames.rts.appFramework.n.r()`: original multiplayer map loader, preserves native local player `z`, copies `z` to `bs`, consumes native server map setup and shared seed. Runner invokes this on its own simulation thread after `aW`.
- Lobby pump uses native `b(1f)` plus `a(1f)`. Loaded-game tick uses original `engine.b(1f,16)`.
- `engine.bX.ad()`: native player state packet 112 containing original `engine.bq` loaded/ready. Resend once after first loaded tick because lobby pump sent initial not-loaded state. Pair2 then avoids the native 15-second simulation ready timeout entirely.
- `engine.cf.b(engine.bs)`: original command constructor queues to `cf.d` when native `B=true`; network prepares, serializes command packet 20 from join, authorizes its source against connection player, schedules at host lockstep step and broadcasts command packet 10. Runner and API never directly execute commands.
- `engine.bX.m("-surrender")`: original local-player chat/network command; join emits packet 140, host resolves authenticated connection player and registers surrender vote; official simulation applies surrender. Pair2 log shows `team surrender`, local player `G=true`.
- UI native `f.g.G()` writes `engine.dq=true` victory; native mission `n.f` increments `numberOfWins` for this path. UI `H()` writes `engine.dt=true` defeat. Native team `H` set by network `g(team)` with `is victorious!`; `G` is no surviving own units or native surrender defeat. `F` represents defeat check for no qualifying building/builder and must not be interpreted alone as final loss.
- Reports read existing native `bX.am.a` checksum at `bX.ah` without mutating it or exposing opponent units in player observations.

Java source builds as Java 8. The obfuscated jar contains a class/package naming collision at `gameFramework.j` and lacks some unused Android overload parameter classes. Exact reflection is used for those native public methods only, without modifying the engine jar.

Evidence: pair1 slot0 and slot1 shared native server ID and seed; both own builders moved 113.875 world units through native queue. Native checksum at frame301 both 8243664, zero desync/resync. Pair2 exact loaded ACK fixed startup, shared seed377342827, checksum3311 both8239492, zero desync/resync; join native surrender observed.
